import { Component, OnInit } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { FormControl, FormGroup } from '@angular/forms';
import { first, map } from 'rxjs/operators';

import  Quill  from 'quill';
import  ImageResize  from 'quill-image-resize-module';

Quill.register('modules/imageResize', ImageResize);

@Component({
  selector: 'app-mock-test',
  templateUrl: './mock-test.component.html',
  styleUrls: ['./mock-test.component.css']
})
export class MockTestComponent implements OnInit {

  editor_modules = {
    toolbar: {
      container: [
        [{ 'font': [] }],
        [{ 'size': ['small', false, 'large', 'huge'] }],
        ['bold', 'italic', 'underline', 'strike'],
        ['blockquote'],
        [{ 'script': 'sub'}, { 'script': 'super' }],
        [{ 'indent': '-1'}, { 'indent': '+1' }],
        [{ 'header': 1 }, { 'header': 2 }],
        [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
        [{ 'color': [] }, { 'background': [] }],
        [{ 'list': 'ordered' }, { 'list': 'bullet' }],
        [{ 'align': [] }],
        ['link', 'image']
      ]
    },
    imageResize: true
  };

  eform = new FormGroup({
    question: new FormControl(''),
    test_name: new FormControl(''),
    option1: new FormControl(''),
    option2: new FormControl(''),
    option3: new FormControl(''),
    option4: new FormControl(''),
    correct_option: new FormControl('')

  });
  text: any;
  fc: any;


  constructor(
    private db: AngularFirestore
  ) { }

  ngOnInit(): void {
  }
 content(event:any){
   console.log(event);
 }

 onSubmit(){
   console.log('in submit')
  console.log(this.eform.value);
  this.text = this.eform.value.editor;
  this.db.collection('questions').add({
    question: this.eform.value.question,
    option1: this.eform.value.option1,
    option2: this.eform.value.option2,
    option3: this.eform.value.option3,
    option4: this.eform.value.option4,
    correct_option: this.eform.value.correct_option,
    mock_test: this.eform.value.test_name
  }).then(resp=>{
    this.db.collection('questions').valueChanges().pipe(first()).subscribe(resp=>{
      console.log(resp);
    })
  })
 }

 getFData(){
   console.log('in get')
   this.db.collection('questions').get().subscribe((querySnapshot) => {
    const tempDoc  = [] as any;
    querySnapshot.forEach((data) => {
      const question = data.data();
      let appObj = { ['id']: data.id, question }
      tempDoc.push(appObj)
    })
    console.log(tempDoc);
    this.fc = tempDoc;
 })
 }
}

import { Component, OnInit } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { FormControl, FormGroup } from '@angular/forms';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-reviews',
  templateUrl: './reviews.component.html',
  styleUrls: ['./reviews.component.css']
})
export class ReviewsComponent implements OnInit {

  editor_modules = {
    toolbar: {
      container: [
        [{ 'font': [] }],
        [{ 'size': ['small', false, 'large', 'huge'] }],
        ['bold', 'italic', 'underline', 'strike'],
        ['blockquote'],
        [{ 'script': 'sub'}, { 'script': 'super' }],
        [{ 'indent': '-1'}, { 'indent': '+1' }],
        [{ 'header': 1 }, { 'header': 2 }],
        [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
        [{ 'color': [] }, { 'background': [] }],
        [{ 'list': 'ordered' }, { 'list': 'bullet' }],
        [{ 'align': [] }],
        ['link', 'image']
      ]
    },
    imageResize: true
  };

  rform = new FormGroup({
    review: new FormControl(''),
    college_name: new FormControl('')

  });

  constructor(
    private db: AngularFirestore
  ) { }

  ngOnInit(): void {
  }

  onSubmit(){
   console.log(this.rform.value);
   this.db.collection('college_review').add({
    review: this.rform.value.review,
    college_name: this.rform.value.college_name
   }).then(resp=>{
     this.db.collection('college_review').valueChanges().pipe(first()).subscribe(resp=>{
       console.log(resp);
     })
   })
  }

}

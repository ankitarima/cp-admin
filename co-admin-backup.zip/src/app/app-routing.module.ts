import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MockTestComponent } from './mock-test/mock-test.component';
import { MockComponent } from './mock/mock.component';
import { ReviewsComponent } from './reviews/reviews.component';

const routes: Routes = [
  {
    path:'',
    component: MockTestComponent
  },
  {
    path: 'mock-test',
    component: MockComponent
  },
  {
    path: 'review',
    component: ReviewsComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
